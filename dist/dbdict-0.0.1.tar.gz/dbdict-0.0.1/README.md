# DB Dict

## Description :
This is a module which has beed designed to make it easier to work with databases 
in python using a dictionary like interface.

## Installation 
`pip install dbdict`
